#LuxuryCarRentalApplication
Luxury Car Rental Application
Please ensure that you have Python, Pip and Django installed. Additionally, you need Pillow installed too. 

## Run the following command to make the necessary migrations:
...
python manage.py makemigrations
...

## Then, migrate the database using: 
...
python manage.py migrate
...

Run the following command to run the server
python manage.py runserver

## Preconfigured Users: 
### Use these to test the apps. 
* Username: Jack
* Username: Jill
* Username: Mario

Password for all test users is:
...
testingpass
...
